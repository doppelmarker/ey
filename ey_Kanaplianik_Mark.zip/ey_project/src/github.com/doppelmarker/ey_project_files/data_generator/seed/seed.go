package seed

import (
	"math/rand"
	"time"
)

// seed package provides side effect for pseudo-random number generator.
func init() {
	rand.Seed(time.Now().UTC().UnixNano())
}
