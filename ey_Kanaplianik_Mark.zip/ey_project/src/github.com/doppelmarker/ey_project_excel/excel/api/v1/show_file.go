package v1

import (
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"github.com/gorilla/mux"
	"html/template"
	"io/ioutil"
	"net/http"
)

// ExcelRow represents a row in Excel document
type ExcelRow struct {
	ID             int
	OpBalActive    float64
	OpBalPassive   float64
	TurnoverDebit  float64
	TurnoverCredit float64
	OutBalActive   float64
	OutBalPassive  float64
}

// ExcelClassGroup represents a subgroup of items
// the number of which can be evaluated as the number of any item in this group divided by 100
type ExcelClassGroup struct {
	GroupNum int
	Rows     []ExcelRow
	Totals   []float64
}

// ExcelClass represents 1 of the given 9 classes in Excel document.
// However, classes are dynamically parsed and saved to the DB, that's why it's amount may vary.
type ExcelClass struct {
	ClassName string
	Groups    []ExcelClassGroup
	Totals    []float64
}

// ExcelData is the highest level data structure for storing Excel document data.
type ExcelData struct {
	Filename string
	Classes  []ExcelClass
	Totals   []float64
}

// KeepAppendingState is a utility data type applied for Excel data structures traverse.
// It possesses 3 states:
// 0 - STOP, means to stop appending the current (row/class) group to the current (class group/class);
// 1 - RESUME, we keep appending;
// 2 - FAIL, some error occurred while appending.
type KeepAppendingState int

const (
	STOP KeepAppendingState = iota
	RESUME
	FAIL
)

const selectRowsByFileIDQuery = `SELECT excel.id, ec.name as className, op_bal_active, op_bal_passive, turnover_debit, turnover_credit, out_bal_active, out_bal_passive
FROM excel
    JOIN excel_classes ec on ec.id = excel.class_id
    JOIN excel_files ef on ef.id = ec.file_id
WHERE file_id=?
`

func ShowFile(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	filename := params["name"]

	files, err := ioutil.ReadDir("./uploads")
	// Whenever directory uploads/ doesn't exist, or it is empty
	if err != nil {
		http.NotFound(w, r)
	}

	for _, f := range files {
		// If file with the given filename exists among ones inside uploads/ dir
		if f.Name() == filename {
			excelData := getExcelData(filename)
			if excelData == nil {
				http.Error(w, "The file being searched is present on server, whereas corresponding data in DB is absent!",
					http.StatusInternalServerError)
				return
			}

			tmpl, _ := template.ParseFiles("templates/fileView.html")
			err := tmpl.Execute(w, *excelData)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
			}
			return
		}
	}
	// If file with the given name in query doesn't exist inside uploads/ dir
	http.NotFound(w, r)
}

func getExcelData(filename string) *ExcelData {
	db, err := sql.Open("mysql", "root:ghostspieler@tcp(127.0.0.1:3306)/ey_db")

	if err != nil {
		return nil
	}

	defer db.Close()
	row := db.QueryRow("SELECT id FROM excel_files WHERE name=?", filename)

	// File id
	var id int

	err = row.Scan(&id)

	rows, err := db.Query(selectRowsByFileIDQuery, id)
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	// Check whether there is some data in DB for the corresponding file, if no, return nil
	if !rows.Next() {
		return nil
	}

	data := ExcelData{Filename: filename}
	excelClasses := make([]ExcelClass, 0)

	defer func() {
		totals := make([]float64, 0, 6)

		var totalOpBalActive, totalOpBalPassive, totalTurnoverDebit,
			totalTurnoverCredit, totalOutBalActive, totalOutBalPassive float64

		for _, class := range excelClasses {
			totalOpBalActive += class.Totals[0]
			totalOpBalPassive += class.Totals[1]
			totalTurnoverDebit += class.Totals[2]
			totalTurnoverCredit += class.Totals[3]
			totalOutBalActive += class.Totals[4]
			totalOutBalPassive += class.Totals[5]
		}

		totals = append(totals, totalOpBalActive, totalOpBalPassive,
			totalTurnoverDebit, totalTurnoverCredit, totalOutBalActive, totalOutBalPassive)

		data.Totals = totals
	}()

	for {
		class, state := getExcelClass(rows)
		if class != nil {
			excelClasses = append(excelClasses, *class)
		}
		switch state {
		case RESUME:
		case STOP, FAIL:
			goto ENDLOOP
		}
	}

ENDLOOP:

	data.Classes = excelClasses

	return &data
}

func getExcelRow(rows *sql.Rows) (r *ExcelRow, className string, groupNum int, err error) {
	r = new(ExcelRow)
	err = rows.Scan(&r.ID, &className, &r.OpBalActive, &r.OpBalPassive, &r.TurnoverDebit, &r.TurnoverCredit, &r.OutBalActive, &r.OutBalPassive)
	if err != nil {
		return nil, "", 0, err
	}
	return r, className, r.ID / 100, nil
}

func getExcelClassGroup(rows *sql.Rows) (g *ExcelClassGroup, className string, state KeepAppendingState) {
	g = new(ExcelClassGroup)
	groupRows := make([]ExcelRow, 0)

	defer func() {
		if g != nil {
			totals := make([]float64, 0, 6)

			var totalOpBalActive, totalOpBalPassive, totalTurnoverDebit,
				totalTurnoverCredit, totalOutBalActive, totalOutBalPassive float64

			for _, row := range groupRows {
				totalOpBalActive += row.OpBalActive
				totalOpBalPassive += row.OpBalPassive
				totalTurnoverDebit += row.TurnoverDebit
				totalTurnoverCredit += row.TurnoverCredit
				totalOutBalActive += row.OutBalActive
				totalOutBalPassive += row.OutBalPassive
			}

			totals = append(totals, totalOpBalActive, totalOpBalPassive,
				totalTurnoverDebit, totalTurnoverCredit, totalOutBalActive, totalOutBalPassive)

			g.Totals = totals
		}
	}()

	for {
		r, className, groupNum, err := getExcelRow(rows)
		if err != nil {
			return nil, "", FAIL
		}
		groupRows = append(groupRows, *r)
		if !rows.Next() {
			g.GroupNum = groupNum
			g.Rows = groupRows
			return g, className, FAIL
		}
		_, nextClassName, nextGroupNum, _ := getExcelRow(rows)
		// If next class begins, ok = false, because we don't want to append next groups to the same class
		if className != nextClassName {
			g.GroupNum = groupNum
			g.Rows = groupRows
			return g, className, STOP
		}
		// Next group encountered, ok = true, keep appending groups to the same class
		if nextGroupNum != groupNum {
			g.GroupNum = groupNum
			g.Rows = groupRows
			return g, className, RESUME
		}
	}
}

func getExcelClass(rows *sql.Rows) (c *ExcelClass, state KeepAppendingState) {
	c = new(ExcelClass)
	var className string
	classGroups := make([]ExcelClassGroup, 0)

	defer func() {
		totals := make([]float64, 0, 6)

		var totalOpBalActive, totalOpBalPassive, totalTurnoverDebit,
			totalTurnoverCredit, totalOutBalActive, totalOutBalPassive float64

		for _, group := range classGroups {
			totalOpBalActive += group.Totals[0]
			totalOpBalPassive += group.Totals[1]
			totalTurnoverDebit += group.Totals[2]
			totalTurnoverCredit += group.Totals[3]
			totalOutBalActive += group.Totals[4]
			totalOutBalPassive += group.Totals[5]
		}

		totals = append(totals, totalOpBalActive, totalOpBalPassive,
			totalTurnoverDebit, totalTurnoverCredit, totalOutBalActive, totalOutBalPassive)

		c.Totals = totals
	}()

	defer func() {
		c.ClassName = className
		c.Groups = classGroups
	}()

	group, className, state := getExcelClassGroup(rows)
	if group != nil {
		classGroups = append(classGroups, *group)
	}
	switch state {
	case STOP:
		return c, RESUME
	case FAIL:
		return c, FAIL
	}

	for {
		group, _, state := getExcelClassGroup(rows)
		if group != nil {
			classGroups = append(classGroups, *group)
		}
		switch state {
		case STOP:
			return c, RESUME
		case FAIL:
			return c, FAIL
		}
	}
}
