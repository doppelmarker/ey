package gen

import (
	"math/rand"
)

var cyrillic = []rune("АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя")

type CyrillicGenerator struct{}

func (gen CyrillicGenerator) GenerateData(args ...interface{}) string {
	if len(args) != 1 {
		panic("wrong number of arguments!")
	}

	size, ok := args[0].(int)
	if !ok {
		panic("size must be int!")
	}

	b := make([]rune, size)
	for i := range b {
		b[i] = cyrillic[rand.Intn(len(cyrillic))]
	}
	return string(b)
}
