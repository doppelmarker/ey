# Table data is for the task 1
create table data
(
    id        int auto_increment
        primary key,
    date      date           null,
    latin     varchar(10)    null,
    cyrillic  varchar(10)    null,
    int_num   int            null,
    float_num decimal(16, 8) null
);

# Remaining tables are used in the task 2
create table excel_files
(
    id   int auto_increment
        primary key,
    name varchar(255) null,
    constraint excel_files_name_uindex
        unique (name)
);

create table excel_classes
(
    id      int auto_increment
        primary key,
    file_id int          null,
    name    varchar(256) null,
    constraint excel_classes_excel_files_id_fk
        foreign key (file_id) references excel_files (id)
            on update cascade on delete cascade
);

create table excel
(
    id              int            not null
        primary key,
    class_id        int            not null,
    op_bal_active   decimal(20, 2) null,
    op_bal_passive  decimal(20, 2) null,
    turnover_debit  decimal(20, 2) null,
    turnover_credit decimal(20, 2) null,
    out_bal_active  decimal(20, 2) null,
    out_bal_passive decimal(20, 2) null,
    constraint excel_excel_classes_id_fk
        foreign key (class_id) references excel_classes (id)
            on update cascade on delete cascade
);

# Stored procedures
create
    definer = root@localhost procedure FloatAvg()
BEGIN
    SELECT AVG(float_num)
    FROM data;
END;

create
    definer = root@localhost procedure IntSum()
BEGIN
    SELECT SUM(int_num)
    FROM data;
END;