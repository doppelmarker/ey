package work

import (
	"bufio"
	"bytes"
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/schollz/progressbar/v3"
	"io"
	"log"
	"os"
	"strings"
)

// ImportData is a top-level function of data importing.
func ImportData(amount int) {
	db, err := sql.Open("mysql", "root:ghostspieler@tcp(127.0.0.1:3306)/ey_db")

	if err != nil {
		panic(err.Error())
	}
	defer db.Close()

	for i := 1; i < amount+1; i++ {
		ImportFile(fmt.Sprintf("generated_files/file%v.txt", i), i, amount, db)
	}
}

// ImportFile imports the file with the given filename to database.
func ImportFile(filename string, current, total int, db *sql.DB) {
	file, err := os.Open(filename)

	if err != nil {
		log.Println(err)
		return
	}
	defer file.Close()

	linesAmount, _ := CountLines(file)

	file.Seek(0, 0)

	barDescription := fmt.Sprintf("[cyan][%v/%v][reset] Importing rows from %v...",
		current, total, filename)

	bar := progressbar.NewOptions(linesAmount,
		progressbar.OptionShowCount(),
		progressbar.OptionEnableColorCodes(true),
		progressbar.OptionSetWidth(15),
		progressbar.OptionSetDescription(barDescription),
		progressbar.OptionSetTheme(progressbar.Theme{
			Saucer:        "[green]=[reset]",
			SaucerHead:    "[green]>[reset]",
			SaucerPadding: " ",
			BarStart:      "[",
			BarEnd:        "]",
		}))

	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		line := scanner.Text()
		data := strings.Split(strings.TrimSuffix(line, "||"), "||")

		date := data[0]
		dayMonthYear := strings.Split(date, ".")
		dbDate := fmt.Sprintf("%s-%s-%s", dayMonthYear[2], dayMonthYear[1], dayMonthYear[0])

		_, err := db.Exec("INSERT INTO data(date, latin, cyrillic, int_num, float_num) VALUES(?,?,?,?,?)",
			dbDate, data[1], data[2], data[3], data[4])
		if err != nil {
			log.Printf("Failed to insert data from %v: %v", filename, err.Error())
			return
		}
		bar.Add(1)
	}
}

// CountLines counts the number of lines in io.Reader, which is equal to the number of '\n' plus 1.
func CountLines(r io.Reader) (int, error) {
	buf := make([]byte, 32*1024)
	count := 0
	lineSep := []byte{'\n'}

	for {
		c, err := r.Read(buf)
		count += bytes.Count(buf[:c], lineSep)

		switch {
		case err == io.EOF:
			return count + 1, nil

		case err != nil:
			return count + 1, err
		}
	}
}
