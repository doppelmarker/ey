package gen

import (
	"fmt"
	"math/rand"
	"time"
)

type DateGenerator struct{}

func (gen DateGenerator) GenerateData(args ...interface{}) string {
	if len(args) != 3 {
		panic("wrong number of arguments!")
	}

	year, ok := args[0].(int)
	if !ok {
		panic("year must be int!")
	}

	month, ok := args[1].(int)
	if !ok {
		panic("month must be int!")
	}

	day, ok := args[1].(int)
	if !ok {
		panic("day must be int!")
	}

	max := time.Now()
	min := max.AddDate(-year, -month, -day)

	delta := max.Unix() - min.Unix()

	sec := rand.Int63n(delta) + min.Unix()

	res := time.Unix(sec, 0)

	return fmt.Sprintf("%02d.%02d.%d", res.Day(), int(res.Month()), res.Year())
}
