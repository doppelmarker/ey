package main

import "github.com/doppelmarker/ey_project_files/work"

const (
	filesAmount = 100
)

func main() {
	work.CreateFiles(filesAmount)
	work.MergeFilesAndDeleteRows("1", filesAmount)
	work.ImportData(filesAmount)
}
