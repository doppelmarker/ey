package work

import (
	"bytes"
	"fmt"
	"github.com/doppelmarker/ey_project_files/data_generator/gen"
	_ "github.com/doppelmarker/ey_project_files/data_generator/seed"
	"github.com/schollz/progressbar/v3"
	"io"
	"log"
	"os"
	"sync"
)

const (
	rowsAmount = 100000
)

// CreateFileJob is a job for a goroutine to create a file.
func CreateFileJob(filepath string, wg *sync.WaitGroup, bar *progressbar.ProgressBar) {
	defer wg.Done()

	if _, err := os.Stat("generated_files"); os.IsNotExist(err) {
		os.Mkdir("generated_files", 0700) // Create the folder for generated files
	}

	file, err := os.Create(filepath)
	defer file.Close()

	if err != nil {
		log.Printf("couldn't create file specified by path %v", filepath)
		return
	}

	gens := []gen.DataGenerator{
		gen.DateGenerator{},
		gen.LatinGenerator{},
		gen.CyrillicGenerator{},
		gen.IntGenerator{},
		gen.FloatGenerator{},
	}

	for i := 0; i < rowsAmount; i++ {
		b := bytes.Buffer{}

		b.WriteString(gens[0].GenerateData(5, 0, 0) + "||")
		b.WriteString(gens[1].GenerateData(10) + "||")
		b.WriteString(gens[2].GenerateData(10) + "||")
		b.WriteString(gens[3].GenerateData(1, 100000000) + "||")
		b.WriteString(gens[4].GenerateData(1., 20.) + "||")

		if i < rowsAmount-1 {
			b.WriteString("\n")
		}

		io.Copy(io.MultiWriter(file, bar), &b)
	}
}

// CreateFiles creates the necessary amount of files in parallel.
func CreateFiles(amount int) {
	wg := sync.WaitGroup{}

	bar := progressbar.DefaultBytes(
		-1,
		"Creating files",
	)

	for i := 1; i < amount+1; i++ {
		wg.Add(1)
		go CreateFileJob(fmt.Sprintf("generated_files/file%v.txt", i), &wg, bar)
	}

	wg.Wait()
}
