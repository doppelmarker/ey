package v1

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/shakinm/xlsReader/xls"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path"
	"strconv"
	"strings"
	"sync"
	"time"
)

type MyFiles struct {
	UploadedList []string
	mtx          sync.Mutex
}

var Files MyFiles

func init() {
	Files = MyFiles{}

	// Running goroutine monitoring files which are present in uploads/ directory
	go func() {
		// curFileNames serves the purpose of a current state
		curFileNames := ([]string)(nil)

		for {
			// Refresh rate is 1 second
			time.Sleep(1000)

			curFileNames = nil

			files, err := ioutil.ReadDir("./uploads")
			// Whenever directory uploads/ doesn't exist, or it is empty
			if err != nil {
				Files.mtx.Lock()
				Files.UploadedList = nil
				Files.mtx.Unlock()
				continue
			}

			for _, f := range files {
				// If file has .xls format
				if strings.HasSuffix(f.Name(), ".xls") {
					curFileNames = append(curFileNames, f.Name())
				}
			}

			// If files were deleted/renamed, update state
			if !cmpSlices(curFileNames, Files.UploadedList) {
				Files.mtx.Lock()
				Files.UploadedList = nil
				for _, fName := range curFileNames {
					Files.UploadedList = append(Files.UploadedList, fName)
				}
				Files.mtx.Unlock()
			}
		}
	}()
}

// cmpSlices compares 2 slices of type string
func cmpSlices(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func UploadFile(w http.ResponseWriter, r *http.Request) {
	r.ParseMultipartForm(10 * 1024 * 1024)
	file, handler, err := r.FormFile("myfile")

	if err != nil {
		fmt.Println(err)
		return
	}
	defer file.Close()

	log.Printf("Got file!\nFile name: %s\nFile size: %d\nFile type: %s",
		handler.Filename, handler.Size, handler.Header.Get("Content-Type"))

	nameExtension := strings.Split(handler.Filename, ".")

	if nameExtension[1] == "xls" {
		if _, err := os.Stat("uploads"); os.IsNotExist(err) {
			os.Mkdir("uploads", 0700) // Create the folder for generated files
		}

		newFile, err := os.Create(fmt.Sprintf(
			"uploads/%v.%v",
			nameExtension[0],
			nameExtension[1]))
		if err != nil {
			fmt.Println(err)
		}
		defer newFile.Close()

		_, err = io.Copy(newFile, file)
		if err != nil {
			fmt.Println(err)
		}

		// Running excel importing procedure as a goroutine to avoid website blocking
		go ExcelToDB(handler.Filename)
	} else {
		fmt.Println("Api supports only .xls files!")
	}

	http.Redirect(w, r, r.Header.Get("Referer"), http.StatusSeeOther)
}

const (
	firstRowNum = 8
	colsNum     = 7
	classWord   = "КЛАСС"
)

func ExcelToDB(filename string) {
	fp := path.Join("uploads", filename)
	workbook, err := xls.OpenFile(fp)

	if err != nil {
		log.Printf("Couldn't open %v. Seems it's not Excel file!", filename)
		return
	}

	sheet, err := workbook.GetSheet(0)

	if err != nil {
		log.Printf("Couldn't first sheet of %v.", filename)
		return
	}

	db, err := sql.Open("mysql", "root:ghostspieler@tcp(127.0.0.1:3306)/ey_db")
	if err != nil {
		panic(err.Error())
	}
	defer db.Close()

	res, _ := db.Exec("INSERT INTO excel_files(name) VALUES(?)", filename)
	fileID, _ := res.LastInsertId()

	var classNum int64 // Current class number
	currentID := 0     // Current ID

	for i := firstRowNum; i < sheet.GetNumberRows(); i++ {
		if row, err := sheet.GetRow(i); err == nil {
			// If ID (first number in a row) is a sum up for the subgroup
			// e.g. the group was 1000, 1001, 1002... and ID equals to 10,
			// we skip this row.
			// strconv.Atoi returns 0, if conversion error occurred, that's why
			// this code also lets us skip rows whose first column is a string,
			// e.g. "ПО КЛАССУ"
			if cell, err := row.GetCol(0); err == nil {
				if nextID, _ := strconv.Atoi(cell.GetString()); nextID <= currentID {
					if strings.HasPrefix(cell.GetString(), classWord) {
						// Inserting new class corresponding to the file being processed
						res, err := db.Exec("INSERT INTO excel_classes(file_id, name) VALUES(?,?)",
							fileID, cell.GetString())
						if err != nil {
							log.Fatalf("Couldn't insert new class for file %v", filename)
						}
						classNum, _ = res.LastInsertId()
					}
					continue
				} else {
					currentID = nextID
				}
			}

			data := make([]string, 6)

			for j := 1; j < colsNum; j++ {
				if cell, err := row.GetCol(j); err == nil {
					data[j-1] = cell.GetString()
				}
			}

			_, err := db.Exec("INSERT INTO excel(id, class_id, op_bal_active, op_bal_passive, turnover_debit, turnover_credit, out_bal_active, out_bal_passive) VALUES(?,?,?,?,?,?,?,?)",
				currentID, classNum, data[0], data[1], data[2], data[3], data[4], data[5])
			if err != nil {
				log.Printf("Couldn't insert row with id %v:%v", currentID, err.Error())
				continue
			}
			log.Printf("Inserted row with id: %v", currentID)
		}
	}
}
