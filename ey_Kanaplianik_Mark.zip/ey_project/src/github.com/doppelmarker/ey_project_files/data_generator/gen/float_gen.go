package gen

import (
	"fmt"
	"math/rand"
)

type FloatGenerator struct{}

func (gen FloatGenerator) GenerateData(args ...interface{}) string {
	if len(args) != 2 {
		panic("wrong number of arguments!")
	}

	left, ok := args[0].(float64)
	if !ok {
		panic("left limit must be float!")
	}

	right, ok := args[1].(float64)
	if !ok {
		panic("right limit be float!")
	}

	return fmt.Sprintf("%.8f", left+rand.Float64()*(right-left))
}
