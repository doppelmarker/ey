package work

import (
	"bufio"
	"bytes"
	"fmt"
	"github.com/schollz/progressbar/v3"
	"io"
	"log"
	"os"
	"strings"
	"sync"
)

type DelCounter struct {
	counter int
	mtx     sync.Mutex
}

var ctr = DelCounter{}

// DeleteRowsJob is a job for a goroutine to remove the rows from file containing the given substring.
func DeleteRowsJob(filename, substr string, wg *sync.WaitGroup, bar *progressbar.ProgressBar) {
	defer wg.Done()

	file, err := os.OpenFile(filename, os.O_RDWR, 0755)

	if err != nil {
		log.Println(err)
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	buf := bytes.Buffer{}

	for scanner.Scan() {
		line := scanner.Text()
		if !strings.Contains(line, substr) {
			buf.WriteString(line + "\n")
		} else {
			ctr.mtx.Lock()
			ctr.counter++
			ctr.mtx.Unlock()
		}
	}

	//deleting last \n
	buf.Truncate(buf.Len() - 1)

	bar.Add(1)

	if err := scanner.Err(); err != nil {
		log.Fatal(err)
	}

	if err := os.Truncate(filename, 0); err != nil {
		log.Printf("Failed to truncate: %v", err)
	}

	file.Seek(0, 0)

	file.Write(buf.Bytes())
}

// MergeFilesAndDeleteRows firstly processes the files and deletes rows with the given substring,
// then it merges these files into merged.txt file.
func MergeFilesAndDeleteRows(substr string, amount int) {
	wg := sync.WaitGroup{}

	barDelRows := progressbar.Default(int64(amount), fmt.Sprintf("Deleting rows with '%v'", substr))

	for i := 1; i < amount+1; i++ {
		wg.Add(1)
		go DeleteRowsJob(fmt.Sprintf("generated_files/file%v.txt", i), substr, &wg, barDelRows)
	}

	wg.Wait()

	newFile, err := os.Create("merged.txt")
	if err != nil {
		log.Fatal(err)
	}
	defer newFile.Close()

	barMerge := progressbar.Default(int64(amount), "Merging files")

	for i := 1; i < amount+1; i++ {
		file, err := os.Open(fmt.Sprintf("generated_files/file%v.txt", i))
		if err != nil {
			log.Fatal(err)
		}

		io.Copy(newFile, file)

		file.Close()

		barMerge.Add(1)
	}

	fmt.Printf("Number of deleted rows: %v", ctr.counter)
}
