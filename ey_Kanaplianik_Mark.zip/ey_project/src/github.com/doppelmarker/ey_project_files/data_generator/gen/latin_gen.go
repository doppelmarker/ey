package gen

import (
	"math/rand"
)

var latin = []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")

type LatinGenerator struct{}

func (gen LatinGenerator) GenerateData(args ...interface{}) string {
	if len(args) != 1 {
		panic("wrong number of arguments!")
	}

	size, ok := args[0].(int)
	if !ok {
		panic("size must be int!")
	}

	b := make([]rune, size)
	for i := range b {
		b[i] = latin[rand.Intn(len(latin))]
	}
	return string(b)
}
