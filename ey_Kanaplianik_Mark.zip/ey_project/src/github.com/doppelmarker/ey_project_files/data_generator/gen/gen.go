package gen

type DataGenerator interface {
	GenerateData(args ...interface{}) string
}
