Executables have been compiled for Windows x64.

Don't forget to setup the database before running the executable.

WARNING! Progress bars work differently depending on the terminal,
you may get unexpected behaviour, different from one demonstrated on screencast.