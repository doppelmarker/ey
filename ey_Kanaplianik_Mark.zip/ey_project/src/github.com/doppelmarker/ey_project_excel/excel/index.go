package excel

import (
	"github.com/doppelmarker/ey_project_excel/excel/api/v1"
	"html/template"
	"net/http"
)

func Index(w http.ResponseWriter, r *http.Request) {
	tmpl, _ := template.ParseFiles("templates/index.html")
	err := tmpl.Execute(w, &v1.Files)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}
