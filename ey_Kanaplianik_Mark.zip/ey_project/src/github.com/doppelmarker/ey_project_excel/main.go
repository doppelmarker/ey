package main

import (
	api "github.com/doppelmarker/ey_project_excel/excel"
	"github.com/doppelmarker/ey_project_excel/excel/api/v1"
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

func main() {
	router := mux.NewRouter()
	router.HandleFunc("/", api.Index).Methods("GET")
	router.HandleFunc("/api/v1/upload", v1.UploadFile).Methods("POST")
	router.HandleFunc("/files/{name}", v1.ShowFile).Methods("GET")

	addr := ":5000"

	log.Printf("Server running on %s", addr)

	log.Fatal(http.ListenAndServe(addr, router))
}
